#importing 
#from car import Car #this worked great but I want to import all the classes
from car import Car, Engine 
my_car = Car("Maruthi Zen", 1400, 25, "Hyderabad", "Vuyyuru" )
my_car.refuel_car(50)
my_car.start_car()
my_car.set_trip("Vuyyuru")
my_car.drive()
my_engine= Engine(1200, 50)
my_engine.start()